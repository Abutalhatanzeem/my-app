package com.smartsplitter.premium;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.webkit.JavascriptInterface;
import android.widget.Toast;
import androidx.core.app.NotificationCompat;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * JavaScript ↔ Android bridge.
 * Accessible from HTML/JS as  window.Android.methodName(...)
 */
public class WebAppInterface {

    private final Context   context;
    private final String    channelId;
    private static final AtomicInteger notifCounter = new AtomicInteger(3000);

    public WebAppInterface(Context context, String channelId) {
        this.context   = context;
        this.channelId = channelId;
    }

    /** Called from JS:  Android.showNotification(title, body) */
    @JavascriptInterface
    public void showNotification(String title, String body) {
        try {
            Intent intent = new Intent(context, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);

            int flags = PendingIntent.FLAG_ONE_SHOT;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
                flags |= PendingIntent.FLAG_IMMUTABLE;

            PendingIntent pi = PendingIntent.getActivity(
                context, notifCounter.get(), intent, flags);

            NotificationCompat.Builder builder = new NotificationCompat.Builder(context, channelId)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(title != null ? title : "SmartSplitter")
                .setContentText(body  != null ? body  : "")
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                .setAutoCancel(true)
                .setContentIntent(pi)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setDefaults(NotificationCompat.DEFAULT_ALL);

            NotificationManager nm =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(notifCounter.getAndIncrement(), builder.build());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /** Called from JS:  Android.showToast(message) */
    @JavascriptInterface
    public void showToast(String message) {
        android.os.Handler mainHandler = new android.os.Handler(
            android.os.Looper.getMainLooper());
        mainHandler.post(() ->
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
        );
    }

    /** Called from JS:  Android.getDeviceInfo()  → "Samsung SM-S928B|14" */
    @JavascriptInterface
    public String getDeviceInfo() {
        return Build.MODEL + "|" + Build.VERSION.RELEASE + "|" + Build.MANUFACTURER;
    }

    /** Called from JS:  Android.isOnline()  → true/false */
    @JavascriptInterface
    public boolean isOnline() {
        android.net.ConnectivityManager cm =
            (android.net.ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return false;
        android.net.NetworkInfo ni = cm.getActiveNetworkInfo();
        return ni != null && ni.isConnected();
    }

    /** Called from JS:  Android.vibrate()  — short haptic feedback */
    @JavascriptInterface
    public void vibrate() {
        android.os.Vibrator v =
            (android.os.Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
        if (v == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            v.vibrate(android.os.VibrationEffect.createOneShot(
                50, android.os.VibrationEffect.DEFAULT_AMPLITUDE));
        } else {
            v.vibrate(50);
        }
    }
}
