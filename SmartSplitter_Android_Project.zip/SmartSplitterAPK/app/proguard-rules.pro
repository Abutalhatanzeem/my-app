# SmartSplitter Premium — ProGuard rules
# Keep JavaScript interface methods (called via reflection from WebView)
-keepclassmembers class com.smartsplitter.premium.WebAppInterface {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.smartsplitter.premium.WebAppInterface { *; }

# Keep MainActivity
-keep class com.smartsplitter.premium.MainActivity { *; }

# AndroidX
-dontwarn androidx.**
-keep class androidx.** { *; }
