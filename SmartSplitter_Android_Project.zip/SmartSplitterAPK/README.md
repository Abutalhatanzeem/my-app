# SmartSplitter Premium — Android APK

## 📁 Project Structure
```
SmartSplitterAPK/
├── app/
│   ├── src/main/
│   │   ├── assets/
│   │   │   └── index.html          ← Your full app (WebView-patched v16.1)
│   │   ├── java/com/smartsplitter/premium/
│   │   │   ├── MainActivity.java   ← WebView host + camera + back nav
│   │   │   └── WebAppInterface.java← JS↔Android bridge (notifications, etc.)
│   │   ├── res/
│   │   │   ├── drawable/ic_notification.xml
│   │   │   ├── layout/activity_main.xml
│   │   │   ├── mipmap-*/ic_launcher*.png  ← All density icons
│   │   │   ├── values/{colors, strings, themes}.xml
│   │   │   └── xml/{backup_rules, data_extraction_rules, file_provider_paths}.xml
│   │   └── AndroidManifest.xml
│   ├── build.gradle
│   └── proguard-rules.pro
├── build.gradle
├── gradle.properties
└── settings.gradle
```

---

## 🛠️ Step-by-Step: Build APK in Android Studio

### Step 1 — Open Project
1. Open **Android Studio** (Hedgehog 2023.1.1 or newer)
2. Click **"Open"** → select the `SmartSplitterAPK` folder
3. Wait for Gradle sync to finish (~2-3 min first time)

### Step 2 — Fix Gradle Wrapper (important!)
If Gradle sync fails, go to:
`File → Project Structure → Project → Gradle Version`
Set to: **8.2** and Android Gradle Plugin: **8.2.2**

Or manually add the wrapper:
```
File → Settings → Build → Gradle → Use Gradle from: Wrapper
```

### Step 3 — Build Debug APK
```
Build → Build Bundle(s) / APK(s) → Build APK(s)
```
APK location after build:
```
app/build/outputs/apk/debug/app-debug.apk
```

### Step 4 — Build Release APK (for sideloading)
```
Build → Generate Signed Bundle / APK → APK → Create New Keystore
```
Fill in keystore details → Build → Release APK will be at:
```
app/build/outputs/apk/release/app-release.apk
```

---

## 📲 Install on Samsung Mobile

### Method 1: USB (Recommended)
1. Enable **Developer Options**: Settings → About Phone → tap "Build number" 7 times
2. Enable **USB Debugging**: Settings → Developer Options → USB Debugging → ON
3. Connect phone to PC
4. In Android Studio: **Run → Run 'app'** → select your device

### Method 2: Sideload APK
1. Copy `app-debug.apk` to phone (WhatsApp, Google Drive, USB)
2. Settings → Apps → Special App Access → **Install Unknown Apps**
3. Allow your file manager to install APKs
4. Tap the APK file → Install

---

## 📲 Install on Huawei MatePad 11.5 (2025) — HarmonyOS

> ⚠️ Huawei has NO Google Play. Sideload only.

### Steps:
1. Settings → **Security** → "Install apps from external sources" → ON
2. Transfer APK file to MatePad via:
   - USB cable from PC
   - Huawei Share (if on same WiFi as another Huawei device)
   - Email it to yourself, download in browser
3. Open **Files** app on MatePad → locate APK → tap → Install

### What works on MatePad:
| Feature | Status |
|---|---|
| All app UI | ✅ Full |
| localStorage data | ✅ Full |
| Firebase sync | ✅ Full (HTTPS) |
| In-app reminders | ✅ Full |
| Camera OCR | ✅ Full |
| Push notifications | ✅ Via Android bridge |
| Google Fonts (UI fonts) | ⚠️ Needs internet (cached after first load) |

---

## 🔧 What Was Changed in index.html

Only 2 surgical patches were applied:

**Patch 1** — WebView detection + Notification API bridge:
```javascript
// Detects Android WebView via user agent
// Overrides window.Notification to call Android.showNotification()
// This makes reminders fire as real Android notifications
window.__isAndroidWebView = true;
window.Notification = function(title, opts) {
    Android.showNotification(title, opts.body);
};
```

**Patch 2** — Skip Service Worker in WebView:
```javascript
if(window.__isAndroidWebView) return; // Skip SW in WebView
```

Everything else is untouched. The same HTML file works in:
- Browser (Chrome/Firefox) — full PWA
- Android WebView APK — full native app
- GitHub Pages — full web app

---

## 🌐 GitHub Upload Instructions

1. Create new repo on GitHub (Private recommended — Firebase key is inside)
2. Upload `SmartSplitter_v16_1_WebView.html` (the patched file)
3. For GitHub Pages: Settings → Pages → Branch: main → Save
4. Access at: `https://YOUR_USERNAME.github.io/REPO_NAME/SmartSplitter_v16_1_WebView.html`

> ⚠️ If repo is Public: Go to Firebase Console → Project Settings →
> API Restrictions → Restrict your key to your GitHub Pages domain only.

---

## 📞 Support
App: SmartSplitter Premium v16.1
Developer: Abu Talha
Package: com.smartsplitter.premium
